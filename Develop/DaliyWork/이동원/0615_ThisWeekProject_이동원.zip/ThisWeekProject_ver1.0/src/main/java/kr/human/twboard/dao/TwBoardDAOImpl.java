package kr.human.twboard.dao;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.session.SqlSession;

import kr.human.tw.vo.TwBoardVO;

public class TwBoardDAOImpl implements TwBoardDAO {
	private static TwBoardDAO instance = new TwBoardDAOImpl();
	private TwBoardDAOImpl() {}
	public static TwBoardDAO getInstance() {
		return instance;
	}
	//-----------------------------------------------------------------------
	@Override
	public int selectCount(SqlSession sqlSession) throws SQLException {
		return sqlSession.selectOne("twBoard.selectCount");
	}
	@Override
	public TwBoardVO selectByIdx(SqlSession sqlSession, int board_idx) throws SQLException {
		return sqlSession.selectOne("twBoard.selectByIdx", board_idx);
	}
	@Override
	public List<TwBoardVO> selectList(SqlSession sqlSession, HashMap<String, Integer> map) throws SQLException {
		return sqlSession.selectList("twBoard.selectList", map);
	}
	@Override
	public void insert(SqlSession sqlSession, TwBoardVO twBoardVO) throws SQLException {
		sqlSession.insert("twBoard.insert", twBoardVO);
	}
	@Override
	public void update(SqlSession sqlSession, TwBoardVO twBoardVO) throws SQLException {
		sqlSession.update("twBoard.update", twBoardVO);
	}
	@Override
	public void delete(SqlSession sqlSession, int board_idx) throws SQLException {
		sqlSession.delete("twBoard.delete", board_idx);
	}
	@Override
	public int selectMaxIdx(SqlSession sqlSession) throws SQLException {
		return sqlSession.selectOne("twBoard.selectMaxIdx");
	}
}
