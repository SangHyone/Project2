package kr.human.twboard.dao;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.session.SqlSession;

import kr.human.tw.vo.TwBoardVO;

public interface TwBoardDAO {
	// 전체 개수 얻어오기
	int selectCount(SqlSession sqlSession) throws SQLException;
	
	// 1개 얻기(idx로)
	TwBoardVO selectByIdx(SqlSession sqlSession, int board_idx) throws SQLException;
	
	// 1페이지 분량 얻기 (리스트로)
	List<TwBoardVO> selectList(SqlSession sqlSession, HashMap<String, Integer> map) throws SQLException;
	
	// 저장
	void insert(SqlSession sqlSession, TwBoardVO twBoardVO) throws SQLException;
	
	// 수정
	void update(SqlSession sqlSession, TwBoardVO twBoardVO) throws SQLException;
	
	// 삭제
	void delete(SqlSession sqlSession, int board_idx) throws SQLException;
	
	// 최신글 얻기
	int selectMaxIdx(SqlSession sqlSession) throws SQLException;
}
