-- 시퀀스 2개 테이블 2개를 만들자!!!!
DROP SEQUENCE twBoard_idx_seq;

DROP SEQUENCE user_idx_seq;

CREATE SEQUENCE user_idx_seq;

CREATE SEQUENCE twBoard_idx_seq;

DROP TABLE twboard;
DROP TABLE USER_INFO ;


CREATE TABLE twboard(
	board_idx NUMBER PRIMARY KEY,
	category varchar2(100) check(category IN ('free', 'travel', 'restaurant', 'sport')) NOT NULL,
	subject varchar2(100) NOT NULL,
	pay NUMBER,
	content varchar2(3000) NOT NULL,
	address varchar2(200) NOT NULL,
	clickCount NUMBER,
	likeCount NUMBER,
	commentCount NUMBER,
	regDate timestamp DEFAULT SYSDATE,
	user_idx NUMBER
);

CREATE TABLE user_info(
	user_idx NUMBER PRIMARY KEY,
	id varchar2(50) NOT NULL UNIQUE,
	password varchar2(50) NOT NULL,
	name varchar2(50) NOT NULL,
	birth DATE NOT NULL,
	gender char(1) NOT NULL check(gender IN ('M', 'F')),
	email varchar2(50) NOT NULL,
	phone varchar2(20) NOT NULL,
	postCode varchar2(10) NOT NULL,
	addr1 varchar2(200) NOT NULL,
	addr2 varchar2(200) NOT NULL,
	use NUMBER check(use IN (0,1,2,3,4,5,6,7,8,9)),
	lev NUMBER check(lev IN (0,1,2,3,4,5,6,7,8,9)),
	point NUMBER DEFAULT 1000
);

INSERT INTO USER_INFO  VALUES 
(user_idx_seq.nextval,'root','1234','최고관리자','1988-09-05','M'
,'ckdlsktkdgus@naver.com','010-5882-0291',' ',' ',' ',1, 9, 1000);
INSERT INTO USER_INFO  VALUES 
(user_idx_seq.nextval,'admin','1234','최고관리자','1988-09-05','M'
,'ckdlsktkdgus@naver.com','010-5882-0291',' ',' ',' ',1, 9, 1000);
INSERT INTO USER_INFO  VALUES 
(user_idx_seq.nextval,'master','1234','최고관리자','1988-09-05','M'
,'ckdlsktkdgus@naver.com','010-5882-0291',' ',' ',' ',1, 9, 1000);
INSERT INTO USER_INFO  VALUES 
(user_idx_seq.nextval,'webmaster','1234','최고관리자','1988-09-05','M'
,'ckdlsktkdgus@naver.com','010-5882-0291',' ',' ',' ',1, 9, 1000);
INSERT INTO USER_INFO  VALUES 
(user_idx_seq.nextval,'sys','1234','최고관리자','1988-09-05','M'
,'ckdlsktkdgus@naver.com','010-5882-0291',' ',' ',' ',1, 9, 1000);
INSERT INTO USER_INFO  VALUES 
(user_idx_seq.nextval,'system','1234','최고관리자','1988-09-05','M'
,'ckdlsktkdgus@naver.com','010-5882-0291',' ',' ',' ',1, 9, 1000);




DROP SEQUENCE upfile_idx_seq;
CREATE SEQUENCE upfile_idx_seq;
DROP TABLE upfile;
CREATE TABLE upfile(
	file_idx NUMBER PRIMARY KEY,
	board_idx NUMBER NOT NULL, -- 원본글번호
	user_idx NUMBER NOT NULL,
	ofileName varchar2(100) NOT NULL, -- 원본 파일명
	sfileName varchar2(100) NOT NULL  -- 저장 파일명
);


CREATE TABLE commentboard(
	comment_idx NUMBER PRIMARY KEY,
	board_idx NUMBER NOT NULL,
	user_idx NUMBER NOT NULL,
	content varchar2(200) NOT NULL,
	regDate	timestamp DEFAULT sysdate,
	category varchar2(100) NOT NULL check(category IN ('free', 'travel', 'restaurant', 'sport'))
);


SELECT * FROM tab;
 SELECT * FROM TWBOARD ;
 SELECT count(*) FROM TWBOARD ;
SELECT * FROM USER_INFO;
DROP TABLE MEMBER;

UPDATE user_info SET use = 1 WHERE id = 'USER1';
UPDATE user_info SET lev = 1 WHERE id = 'USER1';
