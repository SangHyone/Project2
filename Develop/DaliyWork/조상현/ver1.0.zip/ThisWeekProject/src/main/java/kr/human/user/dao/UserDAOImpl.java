package kr.human.user.dao;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.session.SqlSession;

import kr.human.tw.vo.UserVO;

public class UserDAOImpl implements UserDAO {
	private static UserDAO instance = new UserDAOImpl();
	private UserDAOImpl() {}
	public static UserDAO getInstance(){
		return instance;
	}
	//-------------------------------------------------------------------------------
	@Override
	public void insert(SqlSession sqlSession, UserVO userVO) throws SQLException {
		sqlSession.insert("user.insert", userVO);
	}
	@Override
	public void update(SqlSession sqlSession, UserVO userVO) throws SQLException {
		sqlSession.update("user.update", userVO);
	}
	@Override
	public void delete(SqlSession sqlSession, int user_idx) throws SQLException {
		sqlSession.delete("user.delete", user_idx);
	}
	@Override
	public UserVO selectByIdx(SqlSession sqlSession, int user_idx) throws SQLException {
		return sqlSession.selectOne("user.selectByIdx", user_idx);
	}
	@Override
	public UserVO selectByUserid(SqlSession sqlSession, String id) throws SQLException {
		return sqlSession.selectOne("user.selectByUserid", id);
	}
	@Override
	public List<UserVO> selectList(SqlSession sqlSession) throws SQLException {
		return sqlSession.selectList("user.selectList");
	}
	@Override
	public int selectUseridCount(SqlSession sqlSession, String id) throws SQLException {
		return sqlSession.selectOne("user.selectUseridCount", id);
	}
	@Override
	public void updateUse(SqlSession sqlSession, HashMap<String, Integer> map) throws SQLException {
		sqlSession.update("user.updateUse", map);
	}
	@Override
	public void updateLevel(SqlSession sqlSession, HashMap<String, Integer> map) throws SQLException {
		sqlSession.update("user.updateLevel", map);
	}
	@Override
	public List<UserVO> selectByName(SqlSession sqlSession, String name) throws SQLException {
		return sqlSession.selectList("user.selectByName", name);
	}
	@Override
	public void updatePassword(SqlSession sqlSession, HashMap<String, String> map) throws SQLException {
		sqlSession.update("user.updatePassword", map);
	}
	
}
