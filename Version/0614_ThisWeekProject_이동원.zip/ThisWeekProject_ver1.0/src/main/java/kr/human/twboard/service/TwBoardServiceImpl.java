package kr.human.twboard.service;

import java.io.File;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.session.SqlSession;

import kr.human.mybatis.MybatisApp;
import kr.human.tw.vo.PagingVO;
import kr.human.tw.vo.TwBoardVO;
import kr.human.tw.vo.UpFileVO;
import kr.human.twboard.dao.TwBoardDAO;
import kr.human.twboard.dao.TwBoardDAOImpl;
import kr.human.twboard.dao.UpFileDAO;
import kr.human.twboard.dao.UpFileDAOImpl;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class TwBoardServiceImpl implements TwBoardService {
	private static TwBoardService instance = new TwBoardServiceImpl();
	private TwBoardServiceImpl() {}
	public static TwBoardService getInstance() {
		return instance;
	}
	//----------------------------------------------------------------------
	@Override
	public PagingVO<TwBoardVO> selectList(int currentPage, int pageSize, int blockSize) {
		log.info("TwBoardServiceImpl selectList 호출 : " + currentPage + ", " + pageSize + ", " + blockSize);
		PagingVO<TwBoardVO> pagingVO = null;
		SqlSession sqlSession = null;
		TwBoardDAO twBoardDAO = null;
		UpFileDAO    upFileDAO = null;
		try {
			sqlSession = MybatisApp.getSqlSessionFactory().openSession(false);
			twBoardDAO = TwBoardDAOImpl.getInstance();
			upFileDAO = UpFileDAOImpl.getInstance();
			//--------------------------------------------------------------------
			// 1. 전체 개수를 구한다.
			int totalCount = twBoardDAO.selectCount(sqlSession);
			// 2. 페이지를 계산한다.
			pagingVO = new PagingVO<TwBoardVO>(totalCount, currentPage, pageSize, blockSize);
			// 3. 글목록을 가져온다.
			HashMap<String, Integer> map = new HashMap<>();
			map.put("startNo", pagingVO.getStartNo());
			map.put("endNo", pagingVO.getEndNo());
			List<TwBoardVO> list = twBoardDAO.selectList(sqlSession, map);
			// 4. 각각의 글에 대하여 첨부파일 정보를 얻어서 넣자!!!
			if(list!=null) {
				for(TwBoardVO vo : list) {
					List<UpFileVO> fileList = upFileDAO.selectListByRef(sqlSession, vo.getBoard_idx());
					vo.setFileList(fileList);
				}
			}
			// 5. 글의 목록을 pageingVO에 넣어준다.
			pagingVO.setList(list);
			//--------------------------------------------------------------------
			sqlSession.commit();
		}catch (Exception e) {
			sqlSession.rollback();
			e.printStackTrace();
		}finally {
			sqlSession.close();
		}
		log.info("TwBoardServiceImpl selectList 리턴 : " + pagingVO);
		return pagingVO;
	}
	
	
	@Override
	public TwBoardVO selectByIdx(int board_idx) {
		log.info("TwBoardServiceImpl selectByIdx 호출 : " + board_idx);
		TwBoardVO twBoardVO= null;
		//------------------------------------------------------------
		SqlSession sqlSession = null;
		TwBoardDAO twBoardDAO = null;
		UpFileDAO  upFileDAO = null;
		try {
			sqlSession = MybatisApp.getSqlSessionFactory().openSession(false);
			twBoardDAO = TwBoardDAOImpl.getInstance();
			upFileDAO = UpFileDAOImpl.getInstance();
			//--------------------------------------------------------------------
			// 1. 해당 글번호의 글을 가져온다.
			twBoardVO = twBoardDAO.selectByIdx(sqlSession, board_idx);
			// 2. 해당글이 존재하면 첨부파일의 정보를 가져온다.
			if(twBoardVO!=null) {
				List<UpFileVO> fileList = upFileDAO.selectListByRef(sqlSession, board_idx);
				twBoardVO.setFileList(fileList);
			}
			//--------------------------------------------------------------------
			sqlSession.commit();
		}catch (Exception e) {
			sqlSession.rollback();
			e.printStackTrace();
		}finally {
			sqlSession.close();
		}
		//----------------------------------------------------------------------------------
		log.info("TwBoardServiceImpl selectByIdx 리턴 : " + twBoardVO);
		return twBoardVO;
	}
	
	
	@Override
	public void insert(TwBoardVO twBoardVO) {
		log.info("TwBoardServiceImpl insert 호출 : " + twBoardVO);
		//------------------------------------------------------------
		SqlSession sqlSession = null;
		TwBoardDAO twBoardDAO = null;
		UpFileDAO   upFileDAO = null;
		try {
			sqlSession = MybatisApp.getSqlSessionFactory().openSession(false);
			twBoardDAO = TwBoardDAOImpl.getInstance();
			upFileDAO = UpFileDAOImpl.getInstance();
			//--------------------------------------------------------------------
			// 1. 원본글이 존재하면
			if(twBoardVO!=null) {
				// 2. 원본글을 저장한다.
				twBoardDAO.insert(sqlSession, twBoardVO);
				
				// 3. 첨부파일을 저장한다.
				if(twBoardVO.getFileList()!=null) { // 첨부파일이 있다면
					int ref = twBoardDAO.selectMaxIdx(sqlSession); // 지금 저장한 글의 idx를 읽는다.
					for(UpFileVO vo : twBoardVO.getFileList()) {
						vo.setBoard_idx(ref); // 원본글의 글번호를 넣는다.
						upFileDAO.insert(sqlSession, vo);
					}
				}
			}
			//--------------------------------------------------------------------
			sqlSession.commit();
		}catch (Exception e) {
			sqlSession.rollback();
			e.printStackTrace();
		}finally {
			sqlSession.close();
		}
		//----------------------------------------------------------------------------------
	}
	@Override
	public void update(TwBoardVO twBoardVO, String path, String[] delfile) {
		log.info("TwBoardServiceImpl update 호출 : " + twBoardVO + ", " + path + ", " + Arrays.toString(delfile));
		//------------------------------------------------------------
		SqlSession sqlSession = null;
		TwBoardDAO twBoardDAO = null;
		UpFileDAO    upFileDAO = null;
		try {
			sqlSession = MybatisApp.getSqlSessionFactory().openSession(false);
			twBoardDAO = TwBoardDAOImpl.getInstance();
			upFileDAO = UpFileDAOImpl.getInstance();
			//--------------------------------------------------------------------
			// 1. 원본글이 존재하면
			if(twBoardVO!=null) {
				// 2. DB에서 해당 글번호의 글을 읽어온다.
				TwBoardVO dbVO = twBoardDAO.selectByIdx(sqlSession, twBoardVO.getBoard_idx());
				// 3. DB에 글이 있으면서 유저idx가 일치할때만 수정을 수행한다.
				if(dbVO!=null && dbVO.getUser_idx() == twBoardVO.getUser_idx() ){
					// 원본글 수정
					twBoardDAO.update(sqlSession, twBoardVO);
					// 원본글에 추가로 파일이 첨부가 되었다면 파일을 저장한다.
					if(twBoardVO.getFileList()!=null) { // 첨부파일이 있다면
						int ref = twBoardVO.getBoard_idx();
						for(UpFileVO vo : twBoardVO.getFileList()) {
							vo.setBoard_idx(ref); // 원본글의 글번호를 넣는다.
							upFileDAO.insert(sqlSession, vo);
						}
					}
					// 4. 기존파일에 삭제를 선택했다면 기존에 업로드된 파일을 DB와 저장된 파일 자체를 지워준다.
					if(delfile!=null) {
						for(String idx : delfile) {
							try {
								// DB에서 1개를 가져온다.
								UpFileVO dbFileVO = upFileDAO.selectByIdx(sqlSession, Integer.parseInt(idx));
								if(dbFileVO!=null) {
									
									// DB에서 첨부파일 삭제
									upFileDAO.delete(sqlSession, Integer.parseInt(idx));
									
									// 서버에서 파일을 삭제
									File file = new File(path + File.separator + dbFileVO.getSfileName());
									file.delete();
								}
								
							}catch (Exception e) {
								;
							}
						}
					}
				}
			}
			//--------------------------------------------------------------------
			sqlSession.commit();
		}catch (Exception e) {
			sqlSession.rollback();
			e.printStackTrace();
		}finally {
			sqlSession.close();
		}
		//----------------------------------------------------------------------------------			
	}
	
	
	
	@Override
	public void delete(TwBoardVO twBoardVO, String path) {
		log.info("TwBoardServiceImpl delete 호출 : " + twBoardVO + ", " + path);
		//------------------------------------------------------------
		SqlSession sqlSession = null;
		TwBoardDAO twBoardDAO = null;
		UpFileDAO    upFileDAO = null;
		try {
			sqlSession = MybatisApp.getSqlSessionFactory().openSession(false);
			twBoardDAO = TwBoardDAOImpl.getInstance();
			upFileDAO = UpFileDAOImpl.getInstance();
			//--------------------------------------------------------------------
			// 1. 원본글이 존재하면
			if(twBoardVO!=null) {
				// 2. DB에서 해당 글번호의 글을 읽어온다.
				TwBoardVO dbVO = twBoardDAO.selectByIdx(sqlSession, twBoardVO.getBoard_idx());
				// 3. DB에 글이 있으면서 유저idx 일치할때만 수정을 수행한다.
				if( dbVO!=null && dbVO.getUser_idx() == twBoardVO.getUser_idx() ){
					
					// 원본글 삭제
					twBoardDAO.delete(sqlSession, twBoardVO.getBoard_idx());
					
					// 원본글의 첨부파일 목록을 가져온다.
					List<UpFileVO> fileList = upFileDAO.selectListByRef(sqlSession, twBoardVO.getBoard_idx());
					// 첨부파일도 삭제해야 한다.
					if(fileList!=null) {
						for(UpFileVO upFileVO : fileList) {
							// DB의 첨부 삭제
							upFileDAO.delete(sqlSession, upFileVO.getFile_idx());
							// 서버에 저장된 파일 삭제
							File file = new File(path + File.separator + upFileVO.getSfileName());
							file.delete();
						}
					}
				}
			}
			//--------------------------------------------------------------------
			sqlSession.commit();
		}catch (Exception e) {
			sqlSession.rollback();
			e.printStackTrace();
		}finally {
			sqlSession.close();
		}
		//----------------------------------------------------------------------------------		
	}
}
