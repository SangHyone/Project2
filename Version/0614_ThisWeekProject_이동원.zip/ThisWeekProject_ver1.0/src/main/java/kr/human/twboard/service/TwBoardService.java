package kr.human.twboard.service;

import kr.human.tw.vo.PagingVO;
import kr.human.tw.vo.TwBoardVO;

public interface TwBoardService {
	// 1. 목록보기
	PagingVO<TwBoardVO> selectList(int currentPage, int pageSize, int blockSize);
	// 2. 내용보기
	TwBoardVO selectByIdx(int board_idx);
	// 3. 저장하기
	void insert(TwBoardVO twBoardVO);
	// 4. 수정하기
	void update(TwBoardVO twBoardVO, String path, String[] delfile);
	// 5. 삭제하기
	void delete(TwBoardVO twBoardVO, String path);
}
