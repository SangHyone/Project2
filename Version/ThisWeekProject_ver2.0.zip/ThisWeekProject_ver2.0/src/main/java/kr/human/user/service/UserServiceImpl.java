package kr.human.user.service;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.apache.ibatis.session.SqlSession;

import kr.human.mybatis.MybatisApp;
import kr.human.user.dao.UserDAO;
import kr.human.user.dao.UserDAOImpl;
import kr.human.tw.vo.PagingVO;
import kr.human.tw.vo.UserVO;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class UserServiceImpl implements UserService {
	private static UserService instance = new UserServiceImpl();

	private UserServiceImpl() {
	}

	public static UserService getInstance() {
		return instance;
	}

	// -------------------------------------------------------------------------------
	@Override
	public void insert(UserVO userVO, String urlAddress) {
		log.info("UserServiceImpl의 insert호출 : {}, {}", userVO, urlAddress);

		SqlSession sqlSession = null;
		UserDAO userDAO = null;
		try {
			sqlSession = MybatisApp.getSqlSessionFactory().openSession(false);
			userDAO = UserDAOImpl.getInstance();
			// ------------------------------------------------------------------
			if (userVO != null) {
				// DB에 저장을 하고
				userDAO.insert(sqlSession, userVO);
				// 환영이메일 발송
				EmailService.sendMail(userVO.getEmail(), userVO.getName() + "님 회원가입을 환영합니다.",
						"다음 링크를 클릭하여 인증을 하셔야만 회원 가입이 완료됩니다.<br>" + "<a href='" + urlAddress + "&id="
								+ userVO.getId() + "'>인증하기</a>");
			}
			// ------------------------------------------------------------------
			sqlSession.commit();
		} catch (SQLException e) {
			sqlSession.rollback();
			e.printStackTrace();
		} finally {
			if (sqlSession != null)
				sqlSession.close();
		}

	}

	@Override
	public void update(UserVO userVO, String newPassword, HttpSession httpSession) {
		log.info("UserServiceImpl의 update호출 : {}, {}", userVO, newPassword);

		SqlSession sqlSession = null;
		UserDAO userDAO = null;
		try {
			sqlSession = MybatisApp.getSqlSessionFactory().openSession(false);
			userDAO = UserDAOImpl.getInstance();
			// ------------------------------------------------------------------
			if (userVO != null) {
				// DB에서 해당 idx의 회원정보를 가져온다.
				UserVO dbVO = userDAO.selectByIdx(sqlSession, userVO.getUser_idx());
				if(dbVO!=null && dbVO.getPassword().equals(userVO.getPassword())) {
					// 변경을 수행한다.
					userVO.setPassword(newPassword); // 새로운 비번으로 바꿔서
					userDAO.update(sqlSession, userVO);
					
					// 세션의 값을 변경된 값으로 바꿔준다.
					httpSession.setAttribute("userVO", userVO);
				}
			}
			// ------------------------------------------------------------------
			sqlSession.commit();
		} catch (SQLException e) {
			sqlSession.rollback();
			e.printStackTrace();
		} finally {
			if (sqlSession != null)
				sqlSession.close();
		}
	}

	@Override
	public void delete(UserVO userVO, HttpSession httpSession) {
		log.info("UserServiceImpl의 delete호출 : {}", userVO);

		SqlSession sqlSession = null;
		UserDAO userDAO = null;
		try {
			sqlSession = MybatisApp.getSqlSessionFactory().openSession(false);
			userDAO = UserDAOImpl.getInstance();
			// ------------------------------------------------------------------
			if (userVO != null) {
				// DB에서 해당 유저 userid의 회원정보를 가져온다.
				UserVO dbVO = userDAO.selectByUserid(sqlSession, userVO.getId());
				if(dbVO!=null && dbVO.getPassword().equals(userVO.getPassword())) {
					// 삭제를 수행한다.
					// DB에서 바로 지우면 안됨
					// use값에 탈퇴라고 저장을 하고 관리자 모드에서 탈퇴하고 6개월이 지나면 일괄 삭제하는
					// 코드를 만들어주면 된다.
					HashMap<String, Integer> map = new HashMap<String, Integer>();
					map.put("use", 3); // use 0이면 미인증 1이면 인증 2이면 휴면 3이면 탈퇴라고 하자
					map.put("idx", userVO.getUser_idx());
					
					userDAO.updateUse(sqlSession, map);
					
					// 세션의 값을 삭제해준다.
					httpSession.removeAttribute("userVO");
				}
			}
			// ------------------------------------------------------------------
			sqlSession.commit();
		} catch (SQLException e) {
			sqlSession.rollback();
			e.printStackTrace();
		} finally {
			if (sqlSession != null)
				sqlSession.close();
		}
	}


	@Override
	public UserVO searchUserid(String name, String phone) {
		log.info("UserServiceImpl의 searchUserid호출 : {}, {}", name, phone);
		UserVO userVO = null;

		SqlSession sqlSession = null;
		UserDAO userDAO = null;
		try {
			sqlSession = MybatisApp.getSqlSessionFactory().openSession(false);
			userDAO = UserDAOImpl.getInstance();
			// ------------------------------------------------------------------
			// 해당 아이디의 회원 정보를 읽어온다.
			List<UserVO> list = userDAO.selectByName(sqlSession, name);
			if (list != null && list.size() > 0) {
				for (UserVO vo : list) {
					if (vo.getPhone().equals(phone)) {
						userVO = vo;
						break;
					}
				}
			}

			// ------------------------------------------------------------------
			sqlSession.commit();
		} catch (SQLException e) {
			sqlSession.rollback();
			e.printStackTrace();
		} finally {
			if (sqlSession != null)
				sqlSession.close();
		}

		log.info("UserServiceImpl의 searchUserid리턴 : {}", userVO);
		return userVO;
	}

	@Override
	public UserVO searchPassword(String id, String phone) {
		log.info("UserServiceImpl의 searchPassword호출 : {}, {}", id, phone);
		UserVO userVO = null;

		SqlSession sqlSession = null;
		UserDAO userDAO = null;
		try {
			sqlSession = MybatisApp.getSqlSessionFactory().openSession(false);
			userDAO = UserDAOImpl.getInstance();
			// ------------------------------------------------------------------
			// 해당 아이디의 회원 정보를 읽어온다.
			userVO = userDAO.selectByUserid(sqlSession, id);
			if (userVO != null && userVO.getPhone().equals(phone)) {
				// 임시비번을 만들어서 DB의 비번을 변경하고 변경된 비번을 메일로 보낸다.
				String newPassword = PasswordService.makeNewPassword();
				// DB의 비번을 변경하고
				HashMap<String, String> map = new HashMap<String, String>();
				map.put("userid", id);
				map.put("password", newPassword);
				userDAO.updatePassword(sqlSession, map);
				// 변경된 비번을 메일로 발송해준다.
				EmailService.sendMail(userVO.getEmail(), id + "님의 비밀번호 변경입니다.", id + "님의 임시 비밀번호입니다<br>"
						+ "임시비밀번호는 \"" + newPassword + "\"입니다.<br>" + "로그인 하신후 반드시 변경하시기 바랍니다.");
			}

			// ------------------------------------------------------------------
			sqlSession.commit();
		} catch (SQLException e) {
			sqlSession.rollback();
			e.printStackTrace();
		} finally {
			if (sqlSession != null)
				sqlSession.close();
		}

		log.info("UserServiceImpl의 searchPassword리턴 : {}", userVO);
		return userVO;
	}

	@Override
	public boolean login(String id, String password, HttpSession httpSession) {
		log.info("UserServiceImpl의 login호출 : {}, {}", id, password);
		boolean isLogin = false;

		SqlSession sqlSession = null;
		UserDAO userDAO = null;
		try {
			sqlSession = MybatisApp.getSqlSessionFactory().openSession(false);
			userDAO = UserDAOImpl.getInstance();
			// ------------------------------------------------------------------
			// 해당 아이디의 회원 정보를 읽어온다.
			UserVO userVO = userDAO.selectByUserid(sqlSession, id);
			if (userVO != null) { // 해당 아이디의 회원정보가 있다면
				if (userVO.getPassword().equals(password) && userVO.getUse() == 1) {
					httpSession.setAttribute("userVO", userVO);
					isLogin = true;
				}
			}
			// ------------------------------------------------------------------
			sqlSession.commit();
		} catch (SQLException e) {
			sqlSession.rollback();
			e.printStackTrace();
		} finally {
			if (sqlSession != null)
				sqlSession.close();
		}

		log.info("UserServiceImpl의 login리턴 : {}", isLogin);
		return isLogin;
	}

	@Override
	public void logout() {

	}

	@Override
	public boolean emailConfirm(String id) {
		log.info("UserServiceImpl의 emailConfirm호출 : {}", id);
		boolean isConfirm = false;
		SqlSession sqlSession = null;
		UserDAO userDAO = null;
		try {
			sqlSession = MybatisApp.getSqlSessionFactory().openSession(false);
			userDAO = UserDAOImpl.getInstance();
			// ------------------------------------------------------------------
			// 해당 아이디의 회원 정보를 읽어온다.
			UserVO userVO = userDAO.selectByUserid(sqlSession, id);
			if (userVO != null) { // 해당 아이디의 회원정보가 있다면
				// 인증값 변경
				HashMap<String, Integer> map = new HashMap<String, Integer>();
				map.put("use", 1);
				map.put("lev", 1);
				map.put("user_idx", userVO.getUser_idx());
				userDAO.updateUse(sqlSession, map);
				userDAO.updateLevel(sqlSession, map);
				isConfirm = true;
			}
			// ------------------------------------------------------------------
			sqlSession.commit();
		} catch (SQLException e) {
			sqlSession.rollback();
			e.printStackTrace();
		} finally {
			if (sqlSession != null)
				sqlSession.close();
		}

		log.info("UserServiceImpl의 emailConfirm리턴 : {}", isConfirm);
		return isConfirm;
	}

	@Override
	public int idCheck(String id) {
		log.info("UserServiceImpl의 idCheck호출 : {}", id);
		int count = 0;

		SqlSession sqlSession = null;
		UserDAO userDAO = null;
		try {
			sqlSession = MybatisApp.getSqlSessionFactory().openSession(false);
			userDAO = UserDAOImpl.getInstance();
			// ------------------------------------------------------------------
			count = userDAO.selectUseridCount(sqlSession, id);
			// ------------------------------------------------------------------
			sqlSession.commit();
		} catch (SQLException e) {
			sqlSession.rollback();
			e.printStackTrace();
		} finally {
			if (sqlSession != null)
				sqlSession.close();
		}

		log.info("UserServiceImpl의 idCheck리턴 : {}", count);
		return count;
	}

	@Override
	public PagingVO<UserVO> selectList(int currentPage, int pageSize, int blockSize) {
		log.info("UserServiceImpl selectList 호출 : " + currentPage + ", " + pageSize + ", " + blockSize);
		PagingVO<UserVO> pagingVO = null;
		SqlSession sqlSession = null;
		UserDAO userDAO =null;
		try {
			sqlSession = MybatisApp.getSqlSessionFactory().openSession(false);
			userDAO = UserDAOImpl.getInstance();
			//--------------------------------------------------------------------
			// 1. 전체 개수를 구한다.
			int totalCount = userDAO.selectCount(sqlSession);
			// 2. 페이지를 계산한다.
			pagingVO = new PagingVO<UserVO>(totalCount, currentPage, pageSize, blockSize);
			// 3. 글목록을 가져온다.
			HashMap<String, Integer> map = new HashMap<>();
			map.put("startNo", pagingVO.getStartNo());
			map.put("endNo", pagingVO.getEndNo());
			List<UserVO> list = userDAO.selectList(sqlSession, map);
			// 5. 글의 목록을 pageingVO에 넣어준다.
			pagingVO.setList(list);
			//--------------------------------------------------------------------
			sqlSession.commit();
		}catch (Exception e) {
			sqlSession.rollback();
			e.printStackTrace();
		}finally {
			sqlSession.close();
		}
		log.info("UserServiceImpl selectList 리턴 : " + pagingVO);
		return pagingVO;
	}

}
