package kr.human.user.dao;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.session.SqlSession;


import kr.human.tw.vo.UserVO;

public interface UserDAO {
	// 저장
	void insert(SqlSession sqlSession, UserVO  UserVO) throws SQLException;
	// 수정
	void update(SqlSession sqlSession, UserVO UserVO) throws SQLException;
	// 삭제
	void delete(SqlSession sqlSession, int user_idx) throws SQLException;
	// 1개얻기(idx로 얻기)
	UserVO selectByIdx(SqlSession sqlSession, int user_idx) throws SQLException;
	// 1개얻기(userid로 얻기)
	UserVO selectByUserid(SqlSession sqlSession, String id) throws SQLException;
	// name로 얻기
	List<UserVO> selectByName(SqlSession sqlSession, String name) throws SQLException;
	// 모두얻기(관리자)
	List<UserVO> selectList(SqlSession sqlSession, HashMap<String, Integer> map) throws SQLException;
	// 동일한 아이디 개수 얻기(중복확인)
	int selectUseridCount(SqlSession sqlSession, String id) throws SQLException;
	// 인증정보 변경
	void updateUse(SqlSession sqlSession, HashMap<String, Integer> map) throws SQLException;
	// 레벨 변경
	void updateLevel(SqlSession sqlSession, HashMap<String, Integer> map) throws SQLException;
	// 비번 변경
	void updatePassword(SqlSession sqlSession, HashMap<String, String> map) throws SQLException;
	// 전체 개수 얻어오기
	int selectCount(SqlSession sqlSession) throws SQLException;
}
