package kr.human.twboard.dao;

import java.sql.SQLException;
import java.util.List;

import org.apache.ibatis.session.SqlSession;

import kr.human.tw.vo.CommentBoardVO;

public class CommentBoardDAOImpl implements CommentBoardDAO{
	private static CommentBoardDAO instance = new CommentBoardDAOImpl();
	private CommentBoardDAOImpl() {;	}
	public static CommentBoardDAO getInstance() {
		return instance;
	}
	//----------------------------------------------------------------------
	
	@Override
	public int selectCount(SqlSession sqlSession, int board_idx) throws SQLException {
		return sqlSession.selectOne("comment.selectCount", board_idx);
	}
	
	@Override
	public List<CommentBoardVO> selectList(SqlSession sqlSession, int board_idx) throws SQLException {
		return sqlSession.selectList("comment.selectList", board_idx);
	}
	
	@Override
	public CommentBoardVO selectByIdx(SqlSession sqlSession, int comment_idx) throws SQLException {
		return sqlSession.selectOne("comment.selectByIdx", comment_idx);
	}
	
	@Override
	public void insert(SqlSession sqlSession, CommentBoardVO commentBoardVO) throws SQLException {
		sqlSession.insert("comment.insert", commentBoardVO);
	}
	
	@Override
	public void update(SqlSession sqlSession, CommentBoardVO commentBoardVO) throws SQLException {
		sqlSession.update("comment.update", commentBoardVO);
	}
	
	@Override
	public void delete(SqlSession sqlSession, int comment_idx) throws SQLException {
		sqlSession.delete("comment.delete", comment_idx);
	}
	
	@Override
	public void deleteByRef(SqlSession sqlSession, int board_idx) throws SQLException {
		sqlSession.delete("comment.deleteByRef", board_idx);
	}
	
}
